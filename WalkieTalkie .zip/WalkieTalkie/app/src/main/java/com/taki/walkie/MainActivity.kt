package com.taki.walkie

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var led: View
    private lateinit var lcd1: TextView
    private lateinit var lcd2: TextView
    private lateinit var ptt: TextView

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun c(s: String) = Color.parseColor(s)

    private fun rounded(color: Int, r: Int, stroke: Int = 0, sc: Int = Color.BLACK): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), sc)
        return g
    }

    private fun grad(c1: Int, c2: Int, r: Int, stroke: Int = 0, sc: Int = Color.BLACK): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c1, c2))
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(dp(stroke), sc)
        return g
    }

    private fun ovalBg(color: Int, stroke: Int = 0, sc: Int = Color.BLACK): GradientDrawable {
        val g = GradientDrawable()
        g.setShape(GradientDrawable.OVAL)
        g.setColor(color)
        if (stroke > 0) g.setStroke(dp(stroke), sc)
        return g
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(c("#0A0B0C"))
        root.setPadding(dp(14), dp(24), dp(14), dp(14))
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR

        // antenna
        val antenna = View(this)
        antenna.background = grad(c("#3A3F44"), c("#1A1C1E"), 6)
        val alp = LinearLayout.LayoutParams(dp(18), dp(60))
        alp.leftMargin = dp(46)
        root.addView(antenna, alp)

        // radio body
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.background = grad(c("#2E3338"), c("#141618"), 30, 3, Color.BLACK)
        body.setPadding(dp(16), dp(16), dp(16), dp(16))
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // top row: volume knob, LED, channel button
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val knob = TextView(this)
        knob.text = "VOL"
        knob.textSize = 11f
        knob.setTextColor(c("#B0B6BB"))
        knob.typeface = Typeface.DEFAULT_BOLD
        knob.gravity = Gravity.CENTER
        knob.background = ovalBg(c("#454B51"), 4, c("#0D0E0F"))
        knob.setOnClickListener { cycleVolume() }
        top.addView(knob, LinearLayout.LayoutParams(dp(60), dp(60)))

        led = View(this)
        led.background = ovalBg(c("#2E7D32"), 2, c("#0A0A0A"))
        val llp = LinearLayout.LayoutParams(dp(18), dp(18))
        llp.leftMargin = dp(18)
        top.addView(led, llp)

        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))

        val ch = TextView(this)
        ch.text = "CH"
        ch.textSize = 16f
        ch.typeface = Typeface.DEFAULT_BOLD
        ch.setTextColor(Color.BLACK)
        ch.gravity = Gravity.CENTER
        ch.background = grad(c("#FFA726"), c("#E65100"), 10, 3, c("#1A0F00"))
        ch.setOnClickListener { nextChannel() }
        top.addView(ch, LinearLayout.LayoutParams(dp(80), dp(42)))
        body.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // brand label
        val brand = TextView(this)
        brand.text = "WALKIE-TALKIE"
        brand.textSize = 12f
        brand.letterSpacing = 0.25f
        brand.setTextColor(c("#8A9096"))
        brand.typeface = Typeface.DEFAULT_BOLD
        brand.gravity = Gravity.CENTER
        val blp = LinearLayout.LayoutParams(MATCH, WRAP)
        blp.topMargin = dp(10)
        body.addView(brand, blp)

        // LCD
        val lcd = LinearLayout(this)
        lcd.orientation = LinearLayout.VERTICAL
        lcd.background = rounded(c("#B8CC8E"), 8, 4, c("#0A0A0A"))
        lcd.setPadding(dp(12), dp(10), dp(12), dp(10))
        lcd1 = TextView(this)
        lcd1.textSize = 24f
        lcd1.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        lcd1.setTextColor(c("#1D2A12"))
        lcd2 = TextView(this)
        lcd2.textSize = 14f
        lcd2.typeface = Typeface.MONOSPACE
        lcd2.setTextColor(c("#2C3D1B"))
        lcd.addView(lcd1)
        lcd.addView(lcd2)
        lcd.setOnClickListener { nextChannel() }
        val lcdlp = LinearLayout.LayoutParams(MATCH, WRAP)
        lcdlp.topMargin = dp(8)
        body.addView(lcd, lcdlp)

        // speaker grille
        val grille = LinearLayout(this)
        grille.orientation = LinearLayout.VERTICAL
        grille.background = rounded(c("#0C0D0E"), 12)
        grille.setPadding(dp(18), dp(8), dp(18), dp(8))
        for (i in 0 until 5) {
            val slot = View(this)
            slot.background = rounded(c("#2A2D30"), 3)
            val slp = LinearLayout.LayoutParams(MATCH, dp(5))
            slp.topMargin = dp(4)
            slp.bottomMargin = dp(4)
            grille.addView(slot, slp)
        }
        val glp = LinearLayout.LayoutParams(MATCH, WRAP)
        glp.topMargin = dp(12)
        body.addView(grille, glp)

        // PTT button
        ptt = TextView(this)
        ptt.gravity = Gravity.CENTER
        ptt.textSize = 24f
        ptt.typeface = Typeface.DEFAULT_BOLD
        ptt.setTextColor(c("#E0E0E0"))
        ptt.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    WalkieService.instance?.startTalking()
                    pttStyle(true)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    WalkieService.instance?.stopTalking()
                    pttStyle(false)
                }
            }
            true
        }
        pttStyle(false)
        val plp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        plp.topMargin = dp(14)
        body.addView(ptt, plp)

        // menu
        val menu = TextView(this)
        menu.text = "⚙ إعدادات"
        menu.textSize = 14f
        menu.gravity = Gravity.CENTER
        menu.setTextColor(c("#C5CAD0"))
        menu.background = rounded(c("#1E2124"), 10, 2, Color.BLACK)
        menu.setOnClickListener { showMenu() }
        val mlp = LinearLayout.LayoutParams(MATCH, dp(44))
        mlp.topMargin = dp(12)
        body.addView(menu, mlp)

        setContentView(root)
        ensurePermsThenStart()
    }

    private fun pttStyle(on: Boolean) {
        if (on) {
            ptt.text = "TX\nجاري الإرسال"
            ptt.background = grad(c("#E53935"), c("#8E0000"), 18, 4, Color.BLACK)
        } else {
            ptt.text = "PTT\nاضغط مطولًا للتحدث"
            ptt.background = grad(c("#454B51"), c("#23272A"), 18, 4, Color.BLACK)
        }
    }

    private fun cycleVolume() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = maxOf(1, max / 5)
        val nv = if (cur >= max) step else minOf(max, cur + step)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, AudioManager.FLAG_SHOW_UI)
    }

    private fun nextChannel() {
        val svc = WalkieService.instance ?: return
        val ids = listOf(WalkieService.ALL) + svc.peerList().map { it.id }
        val i = ids.indexOf(svc.targetId)
        svc.targetId = ids[(i + 1) % ids.size]
        refresh()
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("الإعدادات")
            .setItems(
                arrayOf("اسم هذا الهاتف", "تشغيل الخدمة", "إيقاف الخدمة", "السماح بالعمل بالخلفية")
            ) { _, w ->
                when (w) {
                    0 -> askName()
                    1 -> ensurePermsThenStart()
                    2 -> stopService(Intent(this, WalkieService::class.java))
                    3 -> askBattery()
                }
            }
            .show()
    }

    private fun askName() {
        val prefs = getSharedPreferences("w", MODE_PRIVATE)
        val et = EditText(this)
        et.setText(prefs.getString("name", null) ?: Build.MODEL)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("اسم هذا الهاتف")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim().ifEmpty { Build.MODEL }
                prefs.edit().putString("name", n).apply()
                WalkieService.instance?.myName = n
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else startSvc()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startSvc()
            askBattery()
        } else {
            Toast.makeText(this, "يلزم إذن الميكروفون", Toast.LENGTH_LONG).show()
        }
    }

    private fun startSvc() {
        if (WalkieService.instance != null) return
        val i = Intent(this, WalkieService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun askBattery() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 300)
        }
    }

    private fun setLed(color: Int) {
        (led.background as GradientDrawable).setColor(color)
    }

    private fun refresh() {
        val svc = WalkieService.instance
        if (svc == null) {
            lcd1.text = "OFFLINE"
            lcd2.text = "الخدمة متوقفة"
            setLed(c("#B71C1C"))
            return
        }
        val list = svc.peerList()
        val rx = System.currentTimeMillis() - svc.lastAudio < 600
        val chName = if (svc.targetId == WalkieService.ALL) "الجميع"
        else (list.firstOrNull { it.id == svc.targetId }?.name ?: "غير متصل")
        lcd1.text = "CH ▸ $chName"
        when {
            svc.talking -> { lcd2.text = "● TX  جاري الإرسال"; setLed(c("#FF1744")) }
            rx -> { lcd2.text = "◀ RX  استقبال"; setLed(c("#00E676")) }
            else -> { lcd2.text = "READY  •  ${list.size} متصل"; setLed(c("#2E7D32")) }
        }
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
