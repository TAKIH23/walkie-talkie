package com.taki.walkie

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random

object SoundFx {
    private const val SR = 22050
    private val rnd = Random()

    private fun tone(f0: Double, f1: Double, ms: Int, vol: Double = 0.6): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / n
            phase += 2 * Math.PI * (f0 + (f1 - f0) * t) / SR
            val env = minOf(1.0, minOf(i, n - i) / (SR * 0.004))
            out[i] = (Math.sin(phase) * vol * env * 32767).toInt().toShort()
        }
        return out
    }

    // static / squelch burst that fades out
    private fun noise(ms: Int, vol: Double): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        var last = 0.0
        for (i in 0 until n) {
            val w = rnd.nextDouble() * 2 - 1
            last = last * 0.55 + w * 0.45
            val env = 1.0 - i.toDouble() / n
            out[i] = (last * vol * env * 32767).toInt().toShort()
        }
        return out
    }

    private fun silence(ms: Int) = ShortArray(SR * ms / 1000)

    private fun concat(vararg a: ShortArray): ShortArray {
        val out = ShortArray(a.sumOf { it.size })
        var p = 0
        for (x in a) { System.arraycopy(x, 0, out, p, x.size); p += x.size }
        return out
    }

    // when I press PTT: rising chirp
    val start: ShortArray by lazy { concat(noise(40, 0.25), tone(900.0, 1700.0, 90, 0.55)) }
    // when I release PTT: roger beep + squelch tail
    val roger: ShortArray by lazy { concat(tone(1500.0, 1500.0, 110, 0.55), silence(20), noise(150, 0.35)) }
    // when incoming voice begins
    val rxStart: ShortArray by lazy { concat(noise(50, 0.3), tone(1100.0, 1100.0, 60, 0.5)) }
    // when incoming voice ends
    val rxEnd: ShortArray by lazy { concat(tone(1500.0, 1500.0, 100, 0.5), silence(20), noise(170, 0.35)) }

    fun play(data: ShortArray) {
        Thread {
            var t: AudioTrack? = null
            try {
                t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.play()
                Thread.sleep(data.size * 1000L / SR + 120)
            } catch (_: Exception) {
            } finally {
                try { t?.release() } catch (_: Exception) {}
            }
        }.start()
    }
}
