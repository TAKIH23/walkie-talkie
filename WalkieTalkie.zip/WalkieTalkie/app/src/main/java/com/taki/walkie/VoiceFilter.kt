package com.taki.walkie

import java.util.Random

// Makes received voice sound like a real two-way radio:
// band-limited (about 300 Hz - 2.8 kHz), compressed, slightly distorted, with faint hiss.
class VoiceFilter {
    private var hpPrevX = 0.0
    private var hpPrevY = 0.0
    private var lp1 = 0.0
    private var lp2 = 0.0
    private val rnd = Random()

    fun process(b: ByteArray, off: Int, len: Int) {
        var i = off
        val end = off + len - 1
        while (i < end) {
            val x = ((b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)).toShort().toDouble()
            val hp = 0.895 * (hpPrevY + x - hpPrevX)
            hpPrevX = x
            hpPrevY = hp
            lp1 += 0.524 * (hp - lp1)
            lp2 += 0.524 * (lp1 - lp2)
            var y = lp2 * 2.4 / 32768.0
            y = Math.tanh(y * 1.6)
            y += (rnd.nextDouble() - 0.5) * 0.035
            if (rnd.nextDouble() < 0.0004) y += (rnd.nextDouble() - 0.5) * 0.5
            val o = (y * 0.85 * 32767).toInt().coerceIn(-32768, 32767)
            b[i] = (o and 0xFF).toByte()
            b[i + 1] = ((o shr 8) and 0xFF).toByte()
            i += 2
        }
    }
}
