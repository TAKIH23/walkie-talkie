package com.taki.walkie

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random

object SoundFx {
    private const val SR = 22050
    private val rnd = Random()

    // electronic beep with harmonics (sounds like a radio tone, not a pure sine)
    private fun beep(f: Double, ms: Int, vol: Double): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            ph += 2 * Math.PI * f / SR
            val env = minOf(1.0, minOf(i, n - i) / (SR * 0.003))
            var s = Math.sin(ph) + 0.35 * Math.sin(3 * ph) + 0.15 * Math.sin(5 * ph)
            s = Math.max(-1.0, Math.min(1.0, s * 1.1))
            out[i] = (s * vol * env * 32767 * 0.8).toInt().toShort()
        }
        return out
    }

    // squelch crash: sharp attack, hissy, fast decay
    private fun crash(ms: Int, vol: Double, attackMs: Int, decay: Double): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        val att = SR * attackMs / 1000.0
        var lastW = 0.0
        for (i in 0 until n) {
            val w = rnd.nextDouble() * 2 - 1
            val hp = w - lastW * 0.6
            lastW = w
            val t = i.toDouble() / n
            val env = minOf(1.0, i / att) * Math.exp(-decay * t)
            out[i] = (hp * 0.6 * vol * env * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    private fun silence(ms: Int) = ShortArray(SR * ms / 1000)

    private fun concat(vararg a: ShortArray): ShortArray {
        val out = ShortArray(a.sumOf { it.size })
        var p = 0
        for (x in a) { System.arraycopy(x, 0, out, p, x.size); p += x.size }
        return out
    }

    // I press PTT: two quick ascending "talk permit" tones
    val start: ShortArray by lazy { concat(beep(1180.0, 65, 0.6), silence(16), beep(1580.0, 75, 0.6)) }
    // I release PTT: roger beep, then squelch tail
    val roger: ShortArray by lazy { concat(beep(1950.0, 95, 0.55), silence(25), crash(220, 0.6, 2, 4.5)) }
    // incoming voice starts: squelch opens
    val rxStart: ShortArray by lazy { crash(110, 0.7, 2, 3.5) }
    // incoming voice ends: roger beep from the other radio + squelch tail
    val rxEnd: ShortArray by lazy { concat(beep(1950.0, 95, 0.5), silence(25), crash(240, 0.65, 2, 4.0)) }

    fun play(data: ShortArray) {
        Thread {
            var t: AudioTrack? = null
            try {
                t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.play()
                Thread.sleep(data.size * 1000L / SR + 120)
            } catch (_: Exception) {
            } finally {
                try { t?.release() } catch (_: Exception) {}
            }
        }.start()
    }
}
