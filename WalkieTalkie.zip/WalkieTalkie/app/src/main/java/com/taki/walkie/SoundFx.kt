package com.taki.walkie

import android.media.AudioAttributes
import android.media.AudioFormat
import android.content.Context
import android.media.AudioTrack
import android.media.SoundPool
import java.util.Random

object SoundFx {
    private const val SR = 22050
    private val rnd = Random()
    private val cache = HashMap<String, ShortArray>()

    private var pool: SoundPool? = null
    private val ids = HashMap<String, Int>()

    fun init(ctx: Context) {
        if (pool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        ids["keyup"] = sp.load(ctx, R.raw.fx_keyup, 1)
        ids["end"] = sp.load(ctx, R.raw.fx_end, 1)
        ids["rxstart"] = sp.load(ctx, R.raw.fx_rxstart, 1)
        ids["rxend"] = sp.load(ctx, R.raw.fx_rxend, 1)
        pool = sp
    }

    private fun real(name: String): Boolean {
        if (style != 0) return false
        val sp = pool ?: return false
        val id = ids[name] ?: return false
        sp.play(id, 1f, 1f, 1, 0, 1f)
        return true
    }

    // 0 = real (cut from the recording), 1 = classic, 2 = digital (P25), 3 = old analog
    @Volatile var style = 0

    // electronic beep with harmonics
    private fun beep(f: Double, ms: Int, vol: Double): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            ph += 2 * Math.PI * f / SR
            val env = minOf(1.0, minOf(i, n - i) / (SR * 0.003))
            var s = Math.sin(ph) + 0.35 * Math.sin(3 * ph) + 0.15 * Math.sin(5 * ph)
            s = Math.max(-1.0, Math.min(1.0, s * 1.1))
            out[i] = (s * vol * env * 32767 * 0.8).toInt().toShort()
        }
        return out
    }

    // mechanical PTT click: short low thump
    private fun click(): ShortArray {
        val n = SR * 8 / 1000
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            val v = Math.sin(2 * Math.PI * 150 * t) * Math.exp(-t / 0.0015) * 0.7
            out[i] = (v * 32767).toInt().toShort()
        }
        return out
    }

    // squelch crash: sharp attack, hissy, fast decay, with random crackle pops
    private fun crash(ms: Int, vol: Double, attackMs: Int, decay: Double, pops: Double): ShortArray {
        val n = SR * ms / 1000
        val out = ShortArray(n)
        val att = SR * attackMs / 1000.0
        var lastW = 0.0
        for (i in 0 until n) {
            val w = rnd.nextDouble() * 2 - 1
            val hp = w - lastW * 0.6
            lastW = w
            val t = i.toDouble() / n
            val env = minOf(1.0, i / att) * Math.exp(-decay * t)
            val pop = if (rnd.nextDouble() < pops) (rnd.nextDouble() * 2 - 1) * 1.2 else 0.0
            out[i] = ((hp * 0.6 + pop) * vol * env * 32767).toInt().coerceIn(-32768, 32767).toShort()
        }
        return out
    }

    private fun silence(ms: Int) = ShortArray(SR * ms / 1000)

    private fun concat(vararg a: ShortArray): ShortArray {
        val out = ShortArray(a.sumOf { it.size })
        var p = 0
        for (x in a) { System.arraycopy(x, 0, out, p, x.size); p += x.size }
        return out
    }

    private fun get(key: String, build: () -> ShortArray): ShortArray =
        synchronized(cache) { cache.getOrPut(key + style) { build() } }

    // I press PTT
    fun playStart() { if (real("keyup")) return; play(get("start") {
        when (style) {
            2 -> concat(click(), beep(1500.0, 120, 0.6))
            3 -> concat(click(), crash(50, 0.6, 2, 3.0, 0.002))
            else -> concat(click(), beep(1180.0, 65, 0.6), silence(16), beep(1580.0, 75, 0.6))
        }
    }) }

    // I release PTT
    fun playRoger() { if (real("end")) return; play(get("roger") {
        when (style) {
            2 -> concat(beep(1400.0, 70, 0.55), silence(20), beep(1000.0, 70, 0.55), silence(8), crash(100, 0.4, 2, 6.0, 0.0))
            3 -> concat(beep(2200.0, 120, 0.55), silence(20), crash(380, 0.8, 2, 3.2, 0.002))
            else -> concat(beep(1950.0, 90, 0.55), silence(25), crash(220, 0.6, 2, 4.5, 0.0006))
        }
    }) }

    // incoming voice starts
    fun playRxStart() { if (real("rxstart")) return; play(get("rxs") {
        when (style) {
            2 -> concat(click(), crash(60, 0.4, 2, 5.0, 0.0))
            3 -> crash(160, 0.8, 2, 2.5, 0.002)
            else -> concat(click(), crash(110, 0.7, 2, 3.5, 0.0004))
        }
    }) }

    // incoming voice ends
    fun playRxEnd() { if (real("rxend")) return; play(get("rxe") {
        when (style) {
            2 -> concat(beep(1400.0, 70, 0.5), silence(20), beep(1000.0, 70, 0.5), silence(8), crash(100, 0.4, 2, 6.0, 0.0))
            3 -> crash(400, 0.8, 2, 3.0, 0.002)
            else -> concat(beep(1950.0, 90, 0.5), silence(25), crash(240, 0.65, 2, 4.0, 0.0006))
        }
    }) }

    // radio powers on: three rising tones
    fun playPower() = play(get("power") {
        concat(beep(800.0, 80, 0.5), silence(30), beep(1000.0, 80, 0.5), silence(30), beep(1300.0, 110, 0.5))
    })

    // channel changed
    fun playChannel() = play(get("chan") { concat(click(), beep(1400.0, 45, 0.5)) })

    // volume changed
    fun playVolume() = play(get("vol") { beep(1000.0, 55, 0.45) })

    fun play(data: ShortArray) {
        Thread {
            var t: AudioTrack? = null
            try {
                t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                t.write(data, 0, data.size)
                t.play()
                Thread.sleep(data.size * 1000L / SR + 120)
            } catch (_: Exception) {
            } finally {
                try { t?.release() } catch (_: Exception) {}
            }
        }.start()
    }
}
