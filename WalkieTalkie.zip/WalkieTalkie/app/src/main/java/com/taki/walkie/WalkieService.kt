package com.taki.walkie

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.*
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.net.*
import java.util.concurrent.ConcurrentHashMap

class WalkieService : Service() {

    data class Peer(val id: String, val name: String, val ip: String, val last: Long)

    companion object {
        const val PORT_AUDIO = 50005
        const val PORT_DISC = 50006
        const val ALL = "00000000"
        const val RATE = 16000
        const val CHANNEL = "walkie"
        @Volatile var instance: WalkieService? = null
    }

    lateinit var myId: String
    @Volatile var myName: String = "هاتف"
    @Volatile var targetId: String = ALL
    @Volatile var talking = false
    @Volatile var lastAudio = 0L
    @Volatile private var running = false
    @Volatile private var bcast: List<InetAddress> = emptyList()
    private val peers = ConcurrentHashMap<String, Peer>()

    private var multicastLock: WifiManager.MulticastLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioSock: DatagramSocket? = null
    private var discSock: DatagramSocket? = null

    fun peerList(): List<Peer> {
        val limit = System.currentTimeMillis() - 8000
        return peers.values.filter { it.last > limit }.sortedBy { it.name }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        instance = this
        val prefs = getSharedPreferences("w", MODE_PRIVATE)
        var id = prefs.getString("id", null)
        if (id == null) {
            id = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 8)
            prefs.edit().putString("id", id).apply()
        }
        myId = id
        myName = prefs.getString("name", null) ?: Build.MODEL

        showForeground()

        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        multicastLock = wm.createMulticastLock("walkie").apply { setReferenceCounted(false); acquire() }
        @Suppress("DEPRECATION")
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "walkie").apply { setReferenceCounted(false); acquire() }
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "walkie:cpu")
            .apply { setReferenceCounted(false); acquire() }

        bcast = computeBroadcasts()
        running = true
        startDiscoverySender()
        startDiscoveryReceiver()
        startAudioReceiver()
    }

    private fun showForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "تلكي ولكي", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("تلكي ولكي يعمل")
            .setContentText("جاهز لاستقبال الصوت")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            val micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            if (micOk) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, type)
        } else {
            startForeground(1, n)
        }
    }

    private fun computeBroadcasts(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (ni.isUp && !ni.isLoopback) {
                    ni.interfaceAddresses.forEach { ia -> ia.broadcast?.let { out.add(it) } }
                }
            }
        } catch (_: Exception) {}
        if (out.isEmpty()) out.add(InetAddress.getByName("255.255.255.255"))
        return out
    }

    private fun startDiscoverySender() {
        Thread {
            var s: DatagramSocket? = null
            try {
                s = DatagramSocket()
                s.broadcast = true
                while (running) {
                    try {
                        bcast = computeBroadcasts()
                        val msg = "WK|$myId|$myName".toByteArray()
                        for (a in bcast) s.send(DatagramPacket(msg, msg.size, a, PORT_DISC))
                    } catch (_: Exception) {}
                    Thread.sleep(2000)
                }
            } catch (_: Exception) {
            } finally { s?.close() }
        }.start()
    }

    private fun startDiscoveryReceiver() {
        Thread {
            while (running) {
                var s: DatagramSocket? = null
                try {
                    s = DatagramSocket(null)
                    s.reuseAddress = true
                    s.bind(InetSocketAddress(PORT_DISC))
                    discSock = s
                    val buf = ByteArray(256)
                    while (running) {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val parts = String(p.data, 0, p.length).split("|", limit = 3)
                        if (parts.size == 3 && parts[0] == "WK" && parts[1] != myId) {
                            peers[parts[1]] = Peer(parts[1], parts[2], p.address.hostAddress ?: "", System.currentTimeMillis())
                        }
                    }
                } catch (_: Exception) {
                    try { Thread.sleep(1000) } catch (_: Exception) {}
                } finally { s?.close() }
            }
        }.start()
    }

    private fun startAudioReceiver() {
        Thread {
            while (running) {
                var s: DatagramSocket? = null
                var track: AudioTrack? = null
                try {
                    s = DatagramSocket(null)
                    s.reuseAddress = true
                    s.bind(InetSocketAddress(PORT_AUDIO))
                    audioSock = s
                    val minBuf = AudioTrack.getMinBufferSize(
                        RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                    )
                    track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setSampleRate(RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .build()
                        )
                        .setBufferSizeInBytes(minBuf * 4)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                    track.play()
                    s.soTimeout = 300
                    val buf = ByteArray(2048)
                    var active = false
                    val filter = VoiceFilter()
                    while (running) {
                        val p = DatagramPacket(buf, buf.size)
                        try {
                            s.receive(p)
                        } catch (e: SocketTimeoutException) {
                            if (active) { active = false; SoundFx.play(SoundFx.rxEnd) }
                            continue
                        }
                        if (p.length <= 16) continue
                        val target = String(p.data, 0, 8)
                        val sender = String(p.data, 8, 8)
                        if (sender == myId) continue
                        if (target != ALL && target != myId) continue
                        if (!active) { active = true; SoundFx.play(SoundFx.rxStart) }
                        lastAudio = System.currentTimeMillis()
                        filter.process(p.data, 16, p.length - 16)
                        track.write(p.data, 16, p.length - 16)
                    }
                } catch (_: Exception) {
                    try { Thread.sleep(1000) } catch (_: Exception) {}
                } finally {
                    try { track?.stop() } catch (_: Exception) {}
                    track?.release()
                    s?.close()
                }
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun startTalking() {
        if (talking) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        talking = true
        Thread {
            val chunk = 640 // 20ms
            SoundFx.play(SoundFx.start)
            try { Thread.sleep(150) } catch (_: Exception) {}
            var rec: AudioRecord? = null
            var s: DatagramSocket? = null
            try {
                val min = AudioRecord.getMinBufferSize(
                    RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(min, chunk * 4)
                )
                s = DatagramSocket()
                s.broadcast = true
                val buf = ByteArray(16 + chunk)
                rec.startRecording()
                while (talking) {
                    val n = rec.read(buf, 16, chunk)
                    if (n <= 0) continue
                    val target = targetId
                    System.arraycopy((target + myId).toByteArray(), 0, buf, 0, 16)
                    if (target == ALL) {
                        for (a in bcast) s.send(DatagramPacket(buf, 16 + n, a, PORT_AUDIO))
                    } else {
                        peers[target]?.let {
                            s.send(DatagramPacket(buf, 16 + n, InetAddress.getByName(it.ip), PORT_AUDIO))
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { rec?.stop() } catch (_: Exception) {}
                rec?.release()
                s?.close()
                talking = false
                SoundFx.play(SoundFx.roger)
            }
        }.start()
    }

    fun stopTalking() { talking = false }

    override fun onDestroy() {
        running = false
        talking = false
        instance = null
        try { audioSock?.close() } catch (_: Exception) {}
        try { discSock?.close() } catch (_: Exception) {}
        try { multicastLock?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
