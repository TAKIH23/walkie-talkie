package com.taki.walkie

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var peersBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var ptt: Button
    private lateinit var nameEdit: EditText
    private var lastSig = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#F4F6F8"))
        }

        root.addView(TextView(this).apply {
            text = "📻 تلكي ولكي"
            textSize = 26f
            setTextColor(Color.parseColor("#1B2733"))
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(status)

        // name row
        val prefs = getSharedPreferences("w", MODE_PRIVATE)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nameEdit = EditText(this).apply {
            hint = "اسم هذا الهاتف"
            setText(prefs.getString("name", null) ?: Build.MODEL)
            setSingleLine()
        }
        row.addView(nameEdit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                val n = nameEdit.text.toString().trim().ifEmpty { Build.MODEL }
                prefs.edit().putString("name", n).apply()
                WalkieService.instance?.myName = n
                Toast.makeText(this@MainActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(row)

        // service buttons
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(Button(this).apply {
            text = "تشغيل الخدمة"
            setOnClickListener { ensurePermsThenStart() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(Button(this).apply {
            text = "إيقاف"
            setOnClickListener { stopService(Intent(this@MainActivity, WalkieService::class.java)) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(Button(this).apply {
            text = "العمل بالخلفية"
            setOnClickListener { askBattery() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row2)

        root.addView(TextView(this).apply {
            text = "إرسال إلى:"
            textSize = 16f
            setPadding(0, dp(8), 0, dp(4))
        })

        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(this)
        sv.addView(peersBox)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        ptt = Button(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        WalkieService.instance?.startTalking()
                        pttStyle(true)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        WalkieService.instance?.stopTalking()
                        pttStyle(false)
                    }
                }
                true
            }
        }
        pttStyle(false)
        root.addView(ptt, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))

        setContentView(root)
        ensurePermsThenStart()
    }

    private fun pttStyle(on: Boolean) {
        ptt.text = if (on) "🎙️ جاري الإرسال..." else "🎙️ اضغط باستمرار للتحدث"
        ptt.setBackgroundColor(Color.parseColor(if (on) "#D32F2F" else "#2E7D32"))
    }

    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else startSvc()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startSvc()
            askBattery()
        } else {
            Toast.makeText(this, "يلزم إذن الميكروفون", Toast.LENGTH_LONG).show()
        }
    }

    private fun startSvc() {
        if (WalkieService.instance != null) return
        val i = Intent(this, WalkieService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun askBattery() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 700)
        }
    }

    private fun refresh() {
        val svc = WalkieService.instance
        if (svc == null) {
            status.text = "⛔ الخدمة متوقفة"
            status.setTextColor(Color.parseColor("#C62828"))
            return
        }
        val list = svc.peerList()
        val receiving = System.currentTimeMillis() - svc.lastAudio < 1000
        status.text = if (receiving) "🔊 يتم استقبال صوت..." else "✅ جاهز • الأجهزة المتصلة: ${list.size}"
        status.setTextColor(Color.parseColor(if (receiving) "#1565C0" else "#2E7D32"))

        if (svc.targetId != WalkieService.ALL && list.none { it.id == svc.targetId }) {
            // keep selection; peer may reappear
        }
        val sig = svc.targetId + "|" + list.joinToString(",") { it.id + it.name }
        if (sig == lastSig) return
        lastSig = sig

        peersBox.removeAllViews()
        addTarget("👥 الجميع", WalkieService.ALL, svc)
        list.forEach { addTarget("📱 ${it.name}", it.id, svc) }
    }

    private fun addTarget(label: String, id: String, svc: WalkieService) {
        val sel = svc.targetId == id
        peersBox.addView(Button(this).apply {
            text = (if (sel) "✔ " else "") + label
            setTextColor(if (sel) Color.WHITE else Color.parseColor("#1B2733"))
            setBackgroundColor(Color.parseColor(if (sel) "#1565C0" else "#DDE3E8"))
            setOnClickListener {
                svc.targetId = id
                lastSig = ""
                refresh()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(6) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
