package com.taki.walkie

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var radio: RadioView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#050607")
        window.navigationBarColor = Color.parseColor("#050607")

        radio = RadioView(this)
        radio.onPttDown = { WalkieService.instance?.startTalking() }
        radio.onPttUp = { WalkieService.instance?.stopTalking() }
        radio.onVol = { cycleVolume() }
        radio.onChannel = { nextChannel() }
        radio.onMenu = { showMenu() }
        setContentView(radio)

        ensurePermsThenStart()
    }

    private fun cycleVolume() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = maxOf(1, max / 5)
        val nv = if (cur >= max) step else minOf(max, cur + step)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, nv, AudioManager.FLAG_SHOW_UI)
        refresh()
    }

    private fun nextChannel() {
        val svc = WalkieService.instance ?: return
        val ids = listOf(WalkieService.ALL) + svc.peerList().map { it.id }
        val i = ids.indexOf(svc.targetId)
        svc.targetId = ids[(i + 1) % ids.size]
        refresh()
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("الإعدادات")
            .setItems(
                arrayOf("اسم هذا الهاتف", "تشغيل الخدمة", "إيقاف الخدمة", "السماح بالعمل بالخلفية")
            ) { _, w ->
                when (w) {
                    0 -> askName()
                    1 -> ensurePermsThenStart()
                    2 -> stopService(Intent(this, WalkieService::class.java))
                    3 -> askBattery()
                }
            }
            .show()
    }

    private fun askName() {
        val prefs = getSharedPreferences("w", MODE_PRIVATE)
        val et = EditText(this)
        et.setText(prefs.getString("name", null) ?: Build.MODEL)
        et.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("اسم هذا الهاتف")
            .setView(et)
            .setPositiveButton("حفظ") { _, _ ->
                val n = et.text.toString().trim().ifEmpty { Build.MODEL }
                prefs.edit().putString("name", n).apply()
                WalkieService.instance?.myName = n
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun ensurePermsThenStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else startSvc()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startSvc()
            askBattery()
        } else {
            Toast.makeText(this, "يلزم إذن الميكروفون", Toast.LENGTH_LONG).show()
        }
    }

    private fun startSvc() {
        if (WalkieService.instance != null) return
        val i = Intent(this, WalkieService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun askBattery() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {}
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 300)
        }
    }

    private fun refresh() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        radio.volume = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxOf(1, max)

        val svc = WalkieService.instance
        if (svc == null) {
            radio.lcd1 = "OFFLINE"
            radio.lcd2 = "الخدمة متوقفة"
            radio.ledColor = Color.parseColor("#B71C1C")
            radio.signalBars = 0
            radio.invalidate()
            return
        }
        val list = svc.peerList()
        val rx = System.currentTimeMillis() - svc.lastAudio < 600
        val chName = if (svc.targetId == WalkieService.ALL) "الجميع"
        else (list.firstOrNull { it.id == svc.targetId }?.name ?: "غير متصل")
        radio.lcd1 = "CH ▸ $chName"
        radio.signalBars = minOf(4, list.size + 1)
        when {
            svc.talking -> { radio.lcd2 = "● TX  جاري الإرسال"; radio.ledColor = Color.parseColor("#FF1744") }
            rx -> { radio.lcd2 = "◀ RX  استقبال"; radio.ledColor = Color.parseColor("#00E676") }
            else -> { radio.lcd2 = "READY  •  ${list.size} متصل"; radio.ledColor = Color.parseColor("#2E7D32") }
        }
        radio.invalidate()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
