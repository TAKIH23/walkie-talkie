package com.taki.walkie

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

class RadioView(ctx: Context) : View(ctx) {

    var lcd1 = "OFFLINE"
    var lcd2 = ""
    var ledColor = Color.parseColor("#2E7D32")
    var volume = 0.5f
    var signalBars = 0
    var pttDown = false

    var onPttDown: () -> Unit = {}
    var onPttUp: () -> Unit = {}
    var onVol: () -> Unit = {}
    var onChannel: () -> Unit = {}
    var onMenu: () -> Unit = {}

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = RectF()
    private val knob = RectF()
    private val chBtn = RectF()
    private val lcdR = RectF()
    private val grille = RectF()
    private val pttR = RectF()
    private val menuR = RectF()
    private var chDown = false
    private var downHit = ""
    private var vw = 0f
    private var vh = 0f

    private fun pc(s: String) = Color.parseColor(s)

    private fun fresh(): Paint {
        p.reset()
        p.isAntiAlias = true
        return p
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        vw = w.toFloat()
        vh = h.toFloat()
        val m = vw * 0.05f
        body.set(m, vh * 0.065f, vw - m, vh - m)
        val bw = body.width()
        val bh = body.height()
        val rowY = body.top + bh * 0.095f
        val kr = bw * 0.10f
        val kx = body.left + bw * 0.20f
        knob.set(kx - kr, rowY - kr, kx + kr, rowY + kr)
        chBtn.set(body.right - bw * 0.32f, rowY - bw * 0.065f, body.right - bw * 0.08f, rowY + bw * 0.065f)
        lcdR.set(body.left + bw * 0.08f, body.top + bh * 0.20f, body.right - bw * 0.08f, body.top + bh * 0.37f)
        grille.set(body.left + bw * 0.08f, body.top + bh * 0.40f, body.right - bw * 0.08f, body.top + bh * 0.53f)
        pttR.set(body.left + bw * 0.08f, body.top + bh * 0.56f, body.right - bw * 0.08f, body.top + bh * 0.86f)
        menuR.set(body.left + bw * 0.30f, body.top + bh * 0.885f, body.right - bw * 0.30f, body.top + bh * 0.955f)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(pc("#050607"))
        drawAntenna(c)
        drawBody(c)
        drawKnob(c)
        drawLed(c)
        drawChannelButton(c)
        drawLcd(c)
        drawGrille(c)
        drawPtt(c)
        drawMenu(c)
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
        bold: Boolean = false, mono: Boolean = false, align: Paint.Align = Paint.Align.CENTER
    ) {
        fresh()
        p.textSize = size
        p.color = color
        p.textAlign = align
        val style = if (bold) Typeface.BOLD else Typeface.NORMAL
        p.typeface = if (mono) Typeface.create(Typeface.MONOSPACE, style) else Typeface.create(Typeface.DEFAULT, style)
        c.drawText(s, x, y, p)
    }

    private fun fit(s: String, maxW: Float, size: Float, bold: Boolean): Float {
        var sz = size
        fresh()
        p.typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        p.textSize = sz
        while (p.measureText(s) > maxW && sz > 8f) {
            sz -= 1f
            p.textSize = sz
        }
        return sz
    }

    private fun drawAntenna(c: Canvas) {
        val x = body.left + body.width() * 0.12f
        val w = body.width() * 0.055f
        val r = RectF(x, 2f, x + w, body.top + 16f)
        fresh()
        p.shader = LinearGradient(
            r.left, 0f, r.right, 0f,
            intArrayOf(pc("#101214"), pc("#656C73"), pc("#15171A")),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(r, w / 2, w / 2, p)
        fresh()
        p.color = Color.argb(90, 0, 0, 0)
        p.strokeWidth = 2f
        var y = 14f
        while (y < body.top) {
            c.drawLine(r.left, y, r.right, y, p)
            y += 9f
        }
    }

    private fun drawBody(c: Canvas) {
        val rad = body.width() * 0.09f
        fresh()
        p.color = Color.argb(130, 0, 0, 0)
        c.drawRoundRect(RectF(body.left + 6f, body.top + 12f, body.right + 6f, body.bottom + 12f), rad, rad, p)

        fresh()
        p.shader = LinearGradient(
            0f, body.top, 0f, body.bottom,
            intArrayOf(pc("#42474D"), pc("#1E2124"), pc("#101214")),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(body, rad, rad, p)

        fresh()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.color = Color.BLACK
        c.drawRoundRect(body, rad, rad, p)

        val hb = RectF(body)
        hb.inset(5f, 5f)
        fresh()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.shader = LinearGradient(0f, hb.top, 0f, hb.bottom, Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRoundRect(hb, rad - 5f, rad - 5f, p)

        // rubber grip ridges on both sides
        val bw = body.width()
        val bh = body.height()
        var y = body.top + bh * 0.22f
        val yEnd = body.top + bh * 0.88f
        while (y < yEnd) {
            fresh()
            p.strokeWidth = 2f
            p.color = Color.argb(110, 0, 0, 0)
            c.drawLine(body.left + 10f, y, body.left + bw * 0.045f, y, p)
            c.drawLine(body.right - bw * 0.045f, y, body.right - 10f, y, p)
            p.color = Color.argb(28, 255, 255, 255)
            c.drawLine(body.left + 10f, y + 2.5f, body.left + bw * 0.045f, y + 2.5f, p)
            c.drawLine(body.right - bw * 0.045f, y + 2.5f, body.right - 10f, y + 2.5f, p)
            y += 11f
        }

        text(c, "TACTICAL  RADIO", body.centerX(), body.top + bh * 0.178f, bw * 0.034f, pc("#8D949B"), bold = true)
    }

    private fun drawKnob(c: Canvas) {
        val cx = knob.centerX()
        val cy = knob.centerY()
        val r = knob.width() / 2
        fresh()
        p.color = Color.argb(160, 0, 0, 0)
        c.drawCircle(cx + 3f, cy + 6f, r, p)

        fresh()
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.5f, pc("#838B93"), pc("#1B1E21"), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)

        for (i in 0 until 40) {
            val a = i * Math.PI * 2 / 40
            fresh()
            p.strokeWidth = 3f
            p.color = Color.argb(180, 0, 0, 0)
            c.drawLine(
                (cx + r * 0.86 * Math.cos(a)).toFloat(), (cy + r * 0.86 * Math.sin(a)).toFloat(),
                (cx + r * 0.99 * Math.cos(a)).toFloat(), (cy + r * 0.99 * Math.sin(a)).toFloat(), p
            )
        }

        fresh()
        p.shader = RadialGradient(cx - r * 0.25f, cy - r * 0.3f, r, pc("#626B74"), pc("#23272B"), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.76f, p)

        c.save()
        c.rotate(-135f + 270f * volume, cx, cy)
        fresh()
        p.color = pc("#F2F2F2")
        c.drawRoundRect(RectF(cx - 3.5f, cy - r * 0.72f, cx + 3.5f, cy - r * 0.30f), 3f, 3f, p)
        c.restore()

        text(c, "VOL", cx, knob.bottom + body.width() * 0.045f, body.width() * 0.032f, pc("#9AA0A6"), bold = true)
    }

    private fun drawLed(c: Canvas) {
        val cx = body.centerX()
        val cy = knob.centerY()
        val r = body.width() * 0.028f
        fresh()
        p.shader = RadialGradient(
            cx, cy, r * 4.5f,
            Color.argb(150, Color.red(ledColor), Color.green(ledColor), Color.blue(ledColor)),
            Color.argb(0, Color.red(ledColor), Color.green(ledColor), Color.blue(ledColor)),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 4.5f, p)
        fresh()
        p.color = Color.BLACK
        c.drawCircle(cx, cy, r + 3f, p)
        fresh()
        p.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.3f, r * 1.3f, Color.WHITE, ledColor, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
    }

    private fun drawChannelButton(c: Canvas) {
        val bezel = RectF(chBtn)
        bezel.inset(-5f, -5f)
        val rad = chBtn.height() * 0.38f
        fresh()
        p.color = pc("#050505")
        c.drawRoundRect(bezel, rad + 4f, rad + 4f, p)
        val face = RectF(chBtn)
        if (chDown) face.offset(0f, 2f)
        fresh()
        p.shader = if (chDown)
            LinearGradient(0f, face.top, 0f, face.bottom, pc("#E65100"), pc("#BF360C"), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, face.top, 0f, face.bottom, pc("#FFB74D"), pc("#E65100"), Shader.TileMode.CLAMP)
        c.drawRoundRect(face, rad, rad, p)
        fresh()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.argb(110, 255, 255, 255)
        val inner = RectF(face)
        inner.inset(3f, 3f)
        c.drawRoundRect(inner, rad - 3f, rad - 3f, p)
        text(c, "CH", face.centerX(), face.centerY() + body.width() * 0.026f, body.width() * 0.075f, pc("#1A0C00"), bold = true)
    }

    private fun drawLcd(c: Canvas) {
        val bezel = RectF(lcdR)
        bezel.inset(-8f, -8f)
        fresh()
        p.shader = LinearGradient(0f, bezel.top, 0f, bezel.bottom, pc("#050607"), pc("#25282C"), Shader.TileMode.CLAMP)
        c.drawRoundRect(bezel, 16f, 16f, p)

        fresh()
        p.shader = LinearGradient(0f, lcdR.top, 0f, lcdR.bottom, pc("#D5E7AB"), pc("#A3BC7B"), Shader.TileMode.CLAMP)
        c.drawRoundRect(lcdR, 9f, 9f, p)

        fresh()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        p.color = Color.argb(70, 0, 0, 0)
        c.drawRoundRect(lcdR, 9f, 9f, p)

        // signal bars
        val bx = lcdR.right - 18f - 4 * 9f
        for (i in 0 until 4) {
            val bhh = 5f + i * 4f
            fresh()
            p.color = if (i < signalBars) pc("#1D2A12") else Color.argb(45, 29, 42, 18)
            c.drawRect(bx + i * 9f, lcdR.top + 24f - bhh, bx + i * 9f + 6f, lcdR.top + 24f, p)
        }

        val maxW = lcdR.width() - 30f
        val s1 = fit(lcd1, maxW, lcdR.height() * 0.30f, true)
        text(c, lcd1, lcdR.left + 16f + 1.5f, lcdR.top + lcdR.height() * 0.58f + 1.5f, s1, Color.argb(45, 20, 30, 10), bold = true, mono = true, align = Paint.Align.LEFT)
        text(c, lcd1, lcdR.left + 16f, lcdR.top + lcdR.height() * 0.58f, s1, pc("#1D2A12"), bold = true, mono = true, align = Paint.Align.LEFT)
        val s2 = fit(lcd2, maxW, lcdR.height() * 0.17f, false)
        text(c, lcd2, lcdR.left + 16f, lcdR.top + lcdR.height() * 0.87f, s2, pc("#2C3D1B"), mono = true, align = Paint.Align.LEFT)
    }

    private fun drawGrille(c: Canvas) {
        fresh()
        p.shader = LinearGradient(0f, grille.top, 0f, grille.bottom, pc("#08090A"), pc("#141618"), Shader.TileMode.CLAMP)
        c.drawRoundRect(grille, 16f, 16f, p)
        val inner = RectF(grille)
        inner.inset(16f, 14f)
        val cols = 16
        val rows = 5
        val cw = inner.width() / cols
        val chh = inner.height() / rows
        val hr = minOf(cw, chh) * 0.30f
        for (r in 0 until rows) {
            for (col in 0 until cols) {
                val off = if (r % 2 == 1) cw * 0.5f else 0f
                val cx = inner.left + cw * (col + 0.5f) + off
                if (cx > inner.right) continue
                val cy = inner.top + chh * (r + 0.5f)
                fresh()
                p.color = Color.argb(50, 255, 255, 255)
                c.drawCircle(cx, cy + 1.6f, hr, p)
                fresh()
                p.color = Color.BLACK
                c.drawCircle(cx, cy, hr, p)
            }
        }
    }

    private fun drawPtt(c: Canvas) {
        val dy = if (pttDown) 5f else 0f
        val bezel = RectF(pttR)
        bezel.inset(-5f, -5f)
        fresh()
        p.color = Color.BLACK
        c.drawRoundRect(bezel, 30f, 30f, p)

        if (!pttDown) {
            fresh()
            p.color = Color.argb(150, 0, 0, 0)
            c.drawRoundRect(RectF(pttR.left, pttR.top + 8f, pttR.right, pttR.bottom + 8f), 26f, 26f, p)
        }

        val face = RectF(pttR.left, pttR.top + dy, pttR.right, pttR.bottom + dy)
        fresh()
        p.shader = if (pttDown)
            LinearGradient(0f, face.top, 0f, face.bottom, intArrayOf(pc("#EF5350"), pc("#B71C1C"), pc("#7F0000")), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        else
            LinearGradient(0f, face.top, 0f, face.bottom, intArrayOf(pc("#5B626A"), pc("#2D3135"), pc("#1F2225")), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(face, 26f, 26f, p)

        // rubber ridges
        for (i in 1 until 10) {
            val y = face.top + face.height() * i / 10f
            fresh()
            p.strokeWidth = 3f
            p.color = Color.argb(75, 0, 0, 0)
            c.drawLine(face.left + 20f, y, face.right - 20f, y, p)
            p.color = Color.argb(30, 255, 255, 255)
            c.drawLine(face.left + 20f, y + 3f, face.right - 20f, y + 3f, p)
        }

        // embossed label plate
        val plate = RectF(face.centerX() - face.width() * 0.34f, face.centerY() - face.height() * 0.27f, face.centerX() + face.width() * 0.34f, face.centerY() + face.height() * 0.27f)
        fresh()
        p.color = if (pttDown) Color.argb(120, 80, 0, 0) else Color.argb(150, 12, 14, 16)
        c.drawRoundRect(plate, 18f, 18f, p)

        val big = face.height() * 0.26f
        val label = if (pttDown) "TX" else "PTT"
        text(c, label, face.centerX() + 2f, face.centerY() + 2f, big, Color.argb(160, 0, 0, 0), bold = true)
        text(c, label, face.centerX(), face.centerY(), big, pc("#ECECEC"), bold = true)
        val sub = if (pttDown) "جاري الإرسال" else "اضغط مطولًا للتحدث"
        text(c, sub, face.centerX(), face.centerY() + face.height() * 0.20f, face.height() * 0.085f, pc("#C3C8CE"))
    }

    private fun drawMenu(c: Canvas) {
        fresh()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.argb(120, 140, 148, 155)
        c.drawRoundRect(menuR, 14f, 14f, p)
        text(c, "إعدادات", menuR.centerX(), menuR.centerY() + body.width() * 0.014f, body.width() * 0.04f, pc("#9AA0A6"))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downHit = when {
                    pttR.contains(x, y) -> "ptt"
                    knob.contains(x, y) -> "vol"
                    chBtn.contains(x, y) -> "ch"
                    lcdR.contains(x, y) -> "lcd"
                    menuR.contains(x, y) -> "menu"
                    else -> ""
                }
                if (downHit == "ptt") { pttDown = true; onPttDown(); invalidate() }
                if (downHit == "ch") { chDown = true; invalidate() }
                return downHit.isNotEmpty()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val up = e.actionMasked == MotionEvent.ACTION_UP
                when (downHit) {
                    "ptt" -> { pttDown = false; onPttUp() }
                    "vol" -> { if (up && knob.contains(x, y)) onVol() }
                    "ch" -> { chDown = false; if (up && chBtn.contains(x, y)) onChannel() }
                    "lcd" -> { if (up && lcdR.contains(x, y)) onChannel() }
                    "menu" -> { if (up && menuR.contains(x, y)) onMenu() }
                }
                downHit = ""
                invalidate()
                return true
            }
        }
        return true
    }
}
